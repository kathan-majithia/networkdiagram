def kat():
    print("Kathan Majithia")